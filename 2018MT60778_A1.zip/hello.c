# include <stdio.h>
#include<string.h> 
#include<stdlib.h> 
#include<unistd.h> 
#include<sys/types.h> 
#include<sys/wait.h> 
#include<readline/readline.h> 
#include<readline/history.h> 

#define size 1024

char *shell_dir;
char* history[1024];
int history_index=0;
int home_dir_length=0;

void printDirectory()
{
	char Dir[size];
	getcwd(Dir, size);
	printf("%s",Dir);
}

void show_history()
{
	printf("Printing last 5 commands:\n\n");
	int index=0;
	if(history_index-5>=0)
		index=history_index-5;
	for(int i=index;i<history_index;i++)
	{
		printf("%s\n",history[i]);
	}
	// printf("\n");
}
int takeInput(char *input)
{
	// printDirectory();
	char *buffer=readline("");
	if(strlen(buffer)!=0)
	{
		// printf("return 0\n");
		strcpy(input, buffer);
		// printf("input= %s",input);
		
		// history_function(input);
		return 0;
	}
	else 
		return 1;	//command read
}

char* implement_cd(char* parsed_command[])
{

	// if(parsed_command[])
		// if(strcmp(parsed_command[0],"cd")==0)

	char Dir1[size];
	getcwd(Dir1, size);
	int present_directory_length=strlen(Dir1);
	chdir(parsed_command[1]);
	char Dir[size];
	getcwd(Dir, size);

	if(strcmp(parsed_command[1],"~")==0)
	{
		chdir(shell_dir);

		char Dir1[size];
		getcwd(Dir1, size);
		char* l=malloc(strlen(Dir1)*sizeof(char));
		strcpy(l,"~");
		return l;
	}

	int new_directory_length=strlen(Dir);

	if(present_directory_length==new_directory_length)
		printf("No such file or directory\n");
	if(new_directory_length>=home_dir_length)
	{
		char newDir[new_directory_length- home_dir_length];
		newDir[0]='~';
		for(int i=home_dir_length;i<new_directory_length;i++)
		{
			newDir[i- home_dir_length+1]=Dir[i];
		}
		newDir[new_directory_length- home_dir_length+1]='\0';
		// printf("newDir= %s\n",newDir);
		char* l=malloc(strlen(newDir)*sizeof(char));
		strcpy(l,newDir);
		return l;
	}

	else
	{
		char* l=malloc(strlen(Dir)*sizeof(char));
		strcpy(l,Dir);
		return l;
	}
	// printf("Dir= %s whereas home dir= %s",Dir,shell_dir );
	// printf("\n");

}

int check_built_in(char* parsed_command[])
{
	pid_t pid = fork();
	// printf("parsed_command[0]= %s\n",parsed_command[0]);
	if(pid==0){
		if(execvp(parsed_command[0], parsed_command)<0)
			printf("Wrong command or arguments\n");
	}
	else 
		wait(NULL);
	// if(strcmp(parsed_command[0],"ls")==0)
	// {
	// 	printf("in built\n");
	// 	return 0;
	// }
	// else if(strcmp(parsed_command[0],"exit")==0)
	// {
	// 	// printf("new type of command\n");
	// 	printf("exiting the shell\n");
	// 	exit(0);
	// 	// return 1;
	// }
	// else if(strcmp(parsed_command[0],"cd")==0)
	// {
	// 	implement_cd(parsed_command);
	// }
	// else{
	// 	printf("new type of command\n");
	// 	return 1;
	// }
	return 1;
}

void parser(char* parsed_command[],char* command)
{

	// char* token1=strtok(command,"\"");
	// printf("token1= %s",token1);
	char* l=malloc(size*sizeof(char));
	strcpy(l,command);
	// printf("command= %s\n",command);

	char* token=strtok(l, " ");
	int i=0;
	while(token!=NULL)
	{
		// printf("token= %s\n",token);
		parsed_command[i]=token;
		token=strtok(NULL, " ");
		char string[size];
		// strcpy(string,token);
		// printf("token= %s\n",string);
		i++;
		// break;
	}
	if(strcmp(parsed_command[0],"cd")==0 && i==1)
	{
		printf("too few arguments\n");
	}
	if(command[0]=='c'&& command[1]=='d' && i==3){
		
		char* str=malloc(size*sizeof(char));
		int index1=0;
		char* str1=malloc(3*sizeof(char));

		str1[0]=command[0];
		str1[1]=command[1];
		str1[2]='\0';
		for(int j=3;j<strlen(command);j++)
		{
			// printf("j= %d",j);
			if(command[j]!='\"')
			{
				str[index1]=command[j];
				index1++;
			}
		}
		str[index1]='\0';
		parsed_command[0]=str1;
		parsed_command[1]=str;
		// printf("str= %s str1= %s\n",str,str1);
		return;
		
	}
	// printf("finally the parsed_command is \n");
	// for(int j=0;j<i;j++)
	// {
		// printf("parsed_command[%d]= %s\n",j,parsed_command[j]);
	// }
	// return 0;
}
int main(int argc, char* argv[])
{
	char input[size];
	char* parsed_command[size];
	// shell_dir=
	char Dir[size];
	getcwd(Dir, size);
	shell_dir=Dir;
	// printf("")
	// for(int i=1;i<=size;i++)
	// {
	// 	if(shell_dir[i-1]=='\0')
	// 		home_dir_length=i;
	// }
	home_dir_length=strlen(Dir);
	// printf("initial directory= %s            with home_dir_length= %d\n",Dir,home_dir_length);
	char *new_dir="~";
	while(1)
	{
		printf("MTL458:%s$ ",new_dir);
		// if(takeInput(input)==0)
		// {
		// 	printf("str= %s",input);
		// }
		
		//Printing directory till now
		// printDirectory();

		if(takeInput(input)==0)
		{
			if(strlen(input)>128){
				printf("Please input with less than 128 characters\n");
				// break;
			}
			// printf("recieved input= %s history_index= %d\n",input,history_index);
			char* l=malloc(strlen(input)*sizeof(char));
			strcpy(l,input);

			history[history_index]=l;
			history_index++;
			parser(parsed_command, input);
			if(strcmp(parsed_command[0],"cd")==0){

				if(strcmp(parsed_command[1],"\0")!=0)
				new_dir=implement_cd(parsed_command);
				// history[history_index]=input;
			
				// history_index++;
			}
			else if(strcmp(parsed_command[0],"history")==0)
				show_history();

			else 	{

			check_built_in(parsed_command);


			}
			
			
			// printf("history_index= %d\n",history_index);

			// show_history();
			printf("\n");
		}
		// printf("input= %s\n",input);

	}
	return 0;
}